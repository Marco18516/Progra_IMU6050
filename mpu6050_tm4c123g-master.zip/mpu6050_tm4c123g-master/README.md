# mpu6050_tm4c123g

Integração do sensor MPU6050 com o microcontrolador Tiva TM4C123G.
